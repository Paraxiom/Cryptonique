pub fn add(a: i32, b: i32) -> i32 {
    a + b
}

// Other math-related functions
