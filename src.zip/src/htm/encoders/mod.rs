pub mod scalar_encoder;
