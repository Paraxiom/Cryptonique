pub mod confusion;
pub mod feistel_network;
